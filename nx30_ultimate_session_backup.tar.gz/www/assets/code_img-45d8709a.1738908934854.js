var a="/images/code_img.png";export{a as _};
