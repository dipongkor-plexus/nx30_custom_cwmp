#!/bin/sh

# Ensure API is in place
if [ ! -f /www/cgi-bin/tr069_api ]; then
    [ -f /mnt/config/cwmp-web/tr069_api ] && cp /mnt/config/cwmp-web/tr069_api /www/cgi-bin/tr069_api
    chmod +x /www/cgi-bin/tr069_api
fi

HTML_FILE=$(ls /www/index*.htm 2>/dev/null | head -n 1)
[ -z "$HTML_FILE" ] && HTML_FILE="/www/index.html"

if [ -f "$HTML_FILE" ]; then
    # Inject only if not already injected
    if ! grep -q "TR069_SETTINGS_HOOK" "$HTML_FILE"; then
        cat << 'HOOK' >> "$HTML_FILE"
<!-- TR069_SETTINGS_HOOK -->
<script>
(function() {
    function injectTR069Menu() {
        var sidebar = document.querySelector('.arco-menu-inner, .side-menu, nav, ul[role="menu"]');
        if (!sidebar || document.getElementById('tr069-menu-item')) return;

        var li = document.createElement('li');
        li.id = 'tr069-menu-item';
        li.className = 'arco-menu-item';
        li.style.cursor = 'pointer';
        li.innerHTML = '<span class="arco-menu-icon"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="4" style="width:16px;height:16px;vertical-align:middle;"><path d="M24 4v40M4 24h40M10 10l28 28M38 10L10 38"/></svg></span><span class="arco-menu-title" style="margin-left:8px;">TR-069 Settings</span>';
        
        li.onclick = function(e) {
            e.preventDefault();
            e.stopPropagation();
            showTR069Modal();
        };
        sidebar.appendChild(li);
    }

    function showTR069Modal() {
        var old = document.getElementById('tr069-modal-overlay');
        if (old) old.remove();

        var overlay = document.createElement('div');
        overlay.id = 'tr069-modal-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:99999;display:flex;align-items:center;justify-content:center;';

        overlay.innerHTML = `
            <div style="background:#fff;border-radius:8px;width:460px;max-width:90%;box-shadow:0 8px 24px rgba(0,0,0,0.2);overflow:hidden;font-family:sans-serif;">
                <div style="background:#165dff;color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;">
                    <h3 style="margin:0;font-size:16px;">TR-069 Client Configuration</h3>
                    <button id="tr069-close" style="background:none;border:none;color:#fff;font-size:18px;cursor:pointer;">&times;</button>
                </div>
                <div style="padding:20px;">
                    <label style="display:flex;align-items:center;margin-bottom:12px;cursor:pointer;">
                        <input type="checkbox" id="tr069_en" style="margin-right:8px;"> Enable TR-069 CWMP
                    </label>
                    <div style="margin-bottom:12px;">
                        <span style="font-size:12px;color:#555;display:block;margin-bottom:4px;">ACS URL</span>
                        <input type="text" id="tr069_url" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="margin-bottom:12px;">
                        <span style="font-size:12px;color:#555;display:block;margin-bottom:4px;">ACS Username</span>
                        <input type="text" id="tr069_usr" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="margin-bottom:12px;">
                        <span style="font-size:12px;color:#555;display:block;margin-bottom:4px;">ACS Password</span>
                        <input type="password" id="tr069_pwd" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="margin-bottom:16px;">
                        <span style="font-size:12px;color:#555;display:block;margin-bottom:4px;">Periodic Interval (Seconds)</span>
                        <input type="number" id="tr069_int" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="display:flex;justify-content:flex-end;gap:10px;">
                        <button id="tr069-cancel" style="padding:7px 16px;border:1px solid #ccc;background:#f2f3f5;border-radius:4px;cursor:pointer;">Cancel</button>
                        <button id="tr069-save" style="padding:7px 16px;border:none;background:#165dff;color:#fff;border-radius:4px;cursor:pointer;">Save</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        fetch('/cgi-bin/tr069_api').then(r => r.json()).then(data => {
            document.getElementById('tr069_en').checked = (data.enable == 1);
            document.getElementById('tr069_url').value = data.acs_url || '';
            document.getElementById('tr069_usr').value = data.acs_username || '';
            document.getElementById('tr069_pwd').value = data.acs_password || '';
            document.getElementById('tr069_int').value = data.periodic_interval || 300;
        }).catch(err => console.error(err));

        document.getElementById('tr069-close').onclick = function() { overlay.remove(); };
        document.getElementById('tr069-cancel').onclick = function() { overlay.remove(); };
        document.getElementById('tr069-save').onclick = function() {
            var payload = {
                enable: document.getElementById('tr069_en').checked ? 1 : 0,
                acs_url: document.getElementById('tr069_url').value,
                acs_username: document.getElementById('tr069_usr').value,
                acs_password: document.getElementById('tr069_pwd').value,
                periodic_interval: parseInt(document.getElementById('tr069_int').value) || 300
            };
            fetch('/cgi-bin/tr069_api', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            }).then(r => r.json()).then(res => {
                alert(res.message || 'Saved!');
                overlay.remove();
            }).catch(e => alert('Failed to save settings'));
        };
    }

    setInterval(injectTR069Menu, 1000);
})();
</script>
HOOK
    fi
fi
