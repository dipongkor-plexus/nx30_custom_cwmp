#!/bin/sh

sleep 5

# Libraries & binary symlinks
[ -d /mnt/config/easycwmp/lib ] && ln -sf /mnt/config/easycwmp/lib/lib* /usr/lib/ 2>/dev/null
[ -f /mnt/config/easycwmp/bin/easycwmpd ] && ln -sf /mnt/config/easycwmp/bin/easycwmpd /usr/sbin/easycwmpd
[ -f /mnt/config/easycwmp/sbin/easycwmp ] && ln -sf /mnt/config/easycwmp/sbin/easycwmp /usr/sbin/easycwmp

# Config & share links
rm -rf /usr/share/easycwmp /etc/config/easycwmp 2>/dev/null
[ -d /mnt/config/easycwmp/usr/share/easycwmp ] && ln -sf /mnt/config/easycwmp/usr/share/easycwmp /usr/share/easycwmp
[ -f /mnt/config/easycwmp/config/easycwmp ] && ln -sf /mnt/config/easycwmp/config/easycwmp /etc/config/easycwmp

# Run service in background
export LD_LIBRARY_PATH="/mnt/config/easycwmp/lib:$LD_LIBRARY_PATH"
killall easycwmpd 2>/dev/null
if [ -x /usr/sbin/easycwmpd ]; then
    /usr/sbin/easycwmpd >/dev/null 2>&1 &
fi

exit 0
