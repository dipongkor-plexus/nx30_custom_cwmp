#!/bin/sh
while true; do
    nc -l -p 8888 -e /www/cgi-bin/tr069_api
done
