#!/bin/sh

# Symlink binaries and shares
ln -sf /mnt/config/cfgmd5/cwmp/bin/easycwmpd /usr/sbin/easycwmpd 2>/dev/null
ln -sf /mnt/config/cfgmd5/cwmp/sbin/easycwmp /usr/sbin/easycwmp 2>/dev/null
mkdir -p /usr/share /etc/config /usr/share/easycwmp /www/cgi-bin
cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/ 2>/dev/null
cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/easycwmp/ 2>/dev/null
[ -f /mnt/config/cfgmd5/cwmp/easycwmp_config ] && cp -f /mnt/config/cfgmd5/cwmp/easycwmp_config /etc/config/easycwmp

# API restore
cp -f /mnt/config/cfgmd5/cwmp/tr069_api /www/cgi-bin/tr069_api
chmod 755 /www/cgi-bin/tr069_api

# Web inject
/bin/sh /mnt/config/cfgmd5/cwmp/inject_cwmp.sh >/dev/null 2>&1

# Export Library path & run
export LD_LIBRARY_PATH="/mnt/config/cfgmd5/cwmp/lib:/usr/lib:/lib:$LD_LIBRARY_PATH"
if ! ps | grep -v grep | grep -q "easycwmpd"; then
    /usr/sbin/easycwmpd >/dev/null 2>&1 &
fi
