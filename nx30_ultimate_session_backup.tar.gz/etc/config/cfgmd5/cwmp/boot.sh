#!/bin/sh
(
    sleep 8
    # Restore Web & API
    /bin/sh /mnt/config/cfgmd5/cwmp/restore_web.sh
    
    # Restore Crontab Watchdog
    if ! grep -q "cfgmd5/cwmp" /etc/crontabs/root 2>/dev/null; then
        echo "* * * * * /bin/sh /mnt/config/cfgmd5/cwmp/restore_web.sh >/dev/null 2>&1" >> /etc/crontabs/root
        /etc/init.d/cron restart 2>/dev/null
    fi
) >/dev/null 2>&1 &
exit 0
