#!/bin/sh

HTML_FILE=$(ls /www/index2025*.htm 2>/dev/null | grep -v "\.bak" | head -n 1)
[ -z "$HTML_FILE" ] && HTML_FILE="/www/index20250207141622.htm"

# ব্যাকআপ থেকে ফ্রেশ কপি নেওয়া
if [ -f "${HTML_FILE}.bak" ]; then
    cp -f "${HTML_FILE}.bak" "$HTML_FILE"
fi

# বর্তমান রিয়েল UCI ভ্যালু রিড করা
URL=$(uci -q get easycwmp.acs.url || echo "http://103.131.144.2:31747/")
USR=$(uci -q get easycwmp.acs.username || echo "admin")
PWD=$(uci -q get easycwmp.acs.password || echo "admin")
PR=$(uci -q get easycwmp.acs.periodic_enable || echo "1")
INT=$(uci -q get easycwmp.acs.periodic_interval || echo "30")

cat << HOOK >> "$HTML_FILE"
<!-- TR069_SETTINGS_HOOK -->
<script>
(function() {
  const TR069_HASH = '#tr069';

  function cleanupOldElements() {
    var oldBtn = document.getElementById('tr069-menu-item');
    if (oldBtn) oldBtn.remove();
    var oldHeader = Array.from(document.querySelectorAll('span, button')).find(el => el.textContent.includes('TR-069 Settings') && el.closest('.arco-page-header, .header, nav'));
    if (oldHeader) oldHeader.remove();
  }

  function renderTR069Page() {
    const mainContent = document.querySelector('.main-content') || 
                        document.querySelector('.arco-layout-content') || 
                        document.querySelector('#app > section > section > main') || 
                        document.querySelector('main');
    if (!mainContent) return;

    // মেনু সিলেকশন আপডেট
    document.querySelectorAll('.arco-menu-item').forEach(el => el.classList.remove('arco-menu-selected', 'is-active'));
    const trItem = document.getElementById('tr069-sub-item-aligned');
    if (trItem) trItem.classList.add('arco-menu-selected', 'is-active');

    // DOM না ভেঙে কন্টেন্ট হাইড/শো করা (যাতে হ্যাং না হয়)
    Array.from(mainContent.children).forEach(function(child) {
      if (child.id !== 'tr069-page-container') {
        child.style.display = 'none';
      }
    });

    let overlay = document.getElementById('tr069-page-container');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'tr069-page-container';
      overlay.style.cssText = 'display: flex; justify-content: center; align-items: flex-start; padding: 30px 24px; width: 100%; box-sizing: border-box;';
      overlay.innerHTML = \`
        <div style="background: #ffffff; border-radius: 8px; padding: 32px 40px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); width: 100%; max-width: 820px; box-sizing: border-box;">
          <h2 style="font-size: 18px; font-weight: 600; color: #1d2129; margin: 0 0 28px 0; border-bottom: 1px solid #f2f3f5; padding-bottom: 16px;">TR-069 Configuration</h2>
          
          <div style="display: flex; flex-direction: column; gap: 20px;">
            <div style="display: flex; align-items: center;">
              <label style="width: 180px; font-size: 14px; color: #4e5969; font-weight: 500;">ACS URL</label>
              <input type="text" id="page_acs_url" value="${URL}" style="flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e5e6eb; border-radius: 4px; font-size: 14px; outline: none;">
            </div>

            <div style="display: flex; align-items: center;">
              <label style="width: 180px; font-size: 14px; color: #4e5969; font-weight: 500;">ACS Username</label>
              <input type="text" id="page_acs_user" value="${USR}" style="flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e5e6eb; border-radius: 4px; font-size: 14px; outline: none;">
            </div>

            <div style="display: flex; align-items: center;">
              <label style="width: 180px; font-size: 14px; color: #4e5969; font-weight: 500;">ACS Password</label>
              <input type="password" id="page_acs_pass" value="${PWD}" style="flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e5e6eb; border-radius: 4px; font-size: 14px; outline: none;">
            </div>

            <div style="display: flex; align-items: center;">
              <label style="width: 180px; font-size: 14px; color: #4e5969; font-weight: 500;">Periodic Inform</label>
              <select id="page_periodic_enable" style="flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e5e6eb; border-radius: 4px; font-size: 14px; background: #fff; outline: none;">
                <option value="1">Enable</option>
                <option value="0">Disable</option>
              </select>
            </div>

            <div style="display: flex; align-items: center;">
              <label style="width: 180px; font-size: 14px; color: #4e5969; font-weight: 500;">Interval (Seconds)</label>
              <input type="number" id="page_periodic_interval" value="${INT}" style="flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e5e6eb; border-radius: 4px; font-size: 14px; outline: none;">
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px; border-top: 1px solid #f2f3f5; padding-top: 24px;">
              <button id="btn_page_save" style="background: #165dff; color: #ffffff; border: none; border-radius: 4px; height: 38px; padding: 0 28px; font-size: 14px; cursor: pointer; font-weight: 500;">Save & Apply</button>
            </div>
          </div>
        </div>
      \`;
      mainContent.appendChild(overlay);

      document.getElementById('page_periodic_enable').value = "${PR}";

      document.getElementById('btn_page_save').onclick = function() {
        const u = encodeURIComponent(document.getElementById('page_acs_url').value);
        const usr = encodeURIComponent(document.getElementById('page_acs_user').value);
        const p = encodeURIComponent(document.getElementById('page_acs_pass').value);
        const pr = encodeURIComponent(document.getElementById('page_periodic_enable').value);
        const inv = encodeURIComponent(document.getElementById('page_periodic_interval').value);

        const saveBtn = document.getElementById('btn_page_save');
        saveBtn.innerText = 'Saving...';
        saveBtn.disabled = true;

        const query = \`action=save&url=\${u}&user=\${usr}&pass=\${p}&periodic=\${pr}&interval=\${inv}\`;
        fetch(\`/cgi-bin/tr069_api?\${query}\`)
          .then(res => res.json())
          .finally(() => {
            alert('Settings saved and applied successfully!');
            saveBtn.innerText = 'Save & Apply';
            saveBtn.disabled = false;
          });
      };
    }

    overlay.style.display = 'flex';
  }

  function handleRoute() {
    cleanupOldElements();
    let overlay = document.getElementById('tr069-page-container');
    const mainContent = document.querySelector('.main-content') || 
                        document.querySelector('.arco-layout-content') || 
                        document.querySelector('#app > section > section > main') || 
                        document.querySelector('main');

    if (window.location.hash === TR069_HASH) {
      renderTR069Page();
    } else {
      if (overlay) overlay.style.display = 'none';
      if (mainContent) {
        Array.from(mainContent.children).forEach(child => {
          if (child.id !== 'tr069-page-container') child.style.display = '';
        });
      }
      const trItem = document.getElementById('tr069-sub-item-aligned');
      if (trItem) trItem.classList.remove('arco-menu-selected', 'is-active');
    }
  }

  function ensureSubMenu() {
    cleanupOldElements();
    const existing = document.getElementById('tr069-sub-item-aligned');
    if (!existing || !document.body.contains(existing)) {
      const allSpans = Array.from(document.querySelectorAll('*'));
      const portTrafficEl = allSpans.find(el => el.children.length === 0 && el.textContent.trim() === 'Port Traffic');
      
      if (portTrafficEl) {
        const portTrafficRow = portTrafficEl.closest('.arco-menu-item') || 
                               portTrafficEl.closest('li') || 
                               portTrafficEl.parentElement;

        if (portTrafficRow && portTrafficRow.parentNode) {
          const cloneItem = portTrafficRow.cloneNode(true);
          cloneItem.id = 'tr069-sub-item-aligned';
          cloneItem.classList.remove('arco-menu-selected', 'is-active');

          const targetTextNode = Array.from(cloneItem.querySelectorAll('*')).find(el => el.children.length === 0 && el.textContent.trim() === 'Port Traffic');
          if (targetTextNode) {
            targetTextNode.textContent = 'TR-069 Settings';
          } else {
            cloneItem.textContent = 'TR-069 Settings';
          }

          cloneItem.style.cursor = 'pointer';
          cloneItem.style.backgroundColor = 'transparent';

          cloneItem.addEventListener('click', function(e) {
            e.stopPropagation();
            window.location.hash = 'tr069';
            handleRoute();
          });

          portTrafficRow.parentNode.insertBefore(cloneItem, portTrafficRow.nextSibling);
        }
      }
    }
  }

  window.addEventListener('hashchange', handleRoute);
  document.addEventListener('click', function(e) {
    var item = e.target.closest('.arco-menu-item');
    if (item && item.id !== 'tr069-sub-item-aligned') {
      if (window.location.hash === TR069_HASH) {
        history.replaceState(null, null, ' ');
      }
      setTimeout(handleRoute, 50);
    }
  });

  setInterval(ensureSubMenu, 500);
})();
</script>
HOOK
