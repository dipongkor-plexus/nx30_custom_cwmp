#!/bin/sh

# Step 1: Read direct UCI values from router
EN=$(uci -q get easycwmp.local.enable || echo "1")
URL=$(uci -q get easycwmp.acs.url || echo "http://edcusers.com:7547")
USR=$(uci -q get easycwmp.acs.username || echo "edcnms")
PWD=$(uci -q get easycwmp.acs.password || echo "edcnms")
INT=$(uci -q get easycwmp.acs.periodic_interval || echo "30")

if [ "$EN" = "1" ]; then
    CHECKED_STATUS="checked"
else
    CHECKED_STATUS=""
fi

# Ensure API binary is copied
[ -f /mnt/config/cfgmd5/cwmp/tr069_api ] && cp -f /mnt/config/cfgmd5/cwmp/tr069_api /www/cgi-bin/tr069_api
chmod +x /www/cgi-bin/tr069_api 2>/dev/null

HTML_FILE=$(ls /www/index*.htm /www/index*.html /www/*.htm /www/*.html 2>/dev/null | head -n 1)

if [ -n "$HTML_FILE" ] && [ -f "$HTML_FILE" ]; then
    # Purono mod clean kora
    sed -i '/<!-- TR069_PERSISTENT_MOD -->/,$d' "$HTML_FILE"

    # Direct bound values injection
    cat << HOOK >> "$HTML_FILE"
<!-- TR069_PERSISTENT_MOD -->
<script>
(function() {
    var TR_CONF = {
        enable: "$EN",
        url: "$URL",
        username: "$USR",
        password: "$PWD",
        interval: "$INT"
    };

    function injectSidebarMenu() {
        if (document.getElementById('tr069-side-menu-item')) return;

        var sideNav = document.querySelector('.arco-menu-inner') || 
                      document.querySelector('ul[role="menu"]') || 
                      document.querySelector('.side-menu') || 
                      document.querySelector('aside ul');

        if (!sideNav) return;

        var li = document.createElement('li');
        li.id = 'tr069-side-menu-item';
        li.className = 'arco-menu-item';
        li.setAttribute('role', 'menuitem');
        li.style.cssText = 'cursor:pointer;display:flex;align-items:center;padding:10px 16px;color:#333;font-size:14px;';
        
        li.innerHTML = '<span class="arco-icon" style="margin-right:10px;font-size:16px;">⚙</span><span>TR-069 Settings</span>';

        li.onmouseover = function() { this.style.backgroundColor = 'rgba(22, 93, 255, 0.08)'; };
        li.onmouseout = function() { this.style.backgroundColor = 'transparent'; };

        li.onclick = function(e) {
            e.preventDefault();
            e.stopPropagation();
            showTR069Modal();
        };

        sideNav.appendChild(li);
    }

    function showTR069Modal() {
        var old = document.getElementById('tr069-modal-overlay');
        if (old) old.remove();

        var isChecked = (TR_CONF.enable === "1") ? "checked" : "";

        var overlay = document.createElement('div');
        overlay.id = 'tr069-modal-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:9999999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;';

        overlay.innerHTML = \`
            <div style="background:#fff;border-radius:8px;width:440px;max-width:92%;box-shadow:0 8px 24px rgba(0,0,0,0.3);overflow:hidden;color:#333;">
                <div style="background:#165dff;color:#fff;padding:12px 18px;display:flex;justify-content:space-between;align-items:center;">
                    <h3 style="margin:0;font-size:15px;font-weight:600;">TR-069 Client Configuration</h3>
                    <span id="tr069-close" style="font-size:22px;cursor:pointer;line-height:1;">&times;</span>
                </div>
                <div style="padding:18px;">
                    <label style="display:flex;align-items:center;margin-bottom:12px;font-size:13px;cursor:pointer;">
                        <input type="checkbox" id="tr069_en" \${isChecked} style="margin-right:8px;"> <strong>Enable TR-069 CWMP</strong>
                    </label>
                    <div style="margin-bottom:10px;">
                        <span style="font-size:12px;color:#666;display:block;margin-bottom:3px;">ACS URL</span>
                        <input type="text" id="tr069_url" value="\${TR_CONF.url}" style="width:100%;box-sizing:border-box;padding:7px;border:1px solid #ccc;border-radius:4px;font-size:13px;">
                    </div>
                    <div style="margin-bottom:10px;">
                        <span style="font-size:12px;color:#666;display:block;margin-bottom:3px;">ACS Username</span>
                        <input type="text" id="tr069_usr" value="\${TR_CONF.username}" style="width:100%;box-sizing:border-box;padding:7px;border:1px solid #ccc;border-radius:4px;font-size:13px;">
                    </div>
                    <div style="margin-bottom:10px;">
                        <span style="font-size:12px;color:#666;display:block;margin-bottom:3px;">ACS Password</span>
                        <input type="password" id="tr069_pwd" value="\${TR_CONF.password}" style="width:100%;box-sizing:border-box;padding:7px;border:1px solid #ccc;border-radius:4px;font-size:13px;">
                    </div>
                    <div style="margin-bottom:16px;">
                        <span style="font-size:12px;color:#666;display:block;margin-bottom:3px;">Periodic Interval (Seconds)</span>
                        <input type="number" id="tr069_int" value="\${TR_CONF.interval}" style="width:100%;box-sizing:border-box;padding:7px;border:1px solid #ccc;border-radius:4px;font-size:13px;">
                    </div>
                    <div style="display:flex;justify-content:flex-end;gap:10px;">
                        <button id="tr069-cancel" style="padding:6px 14px;border:1px solid #ccc;background:#f5f5f5;border-radius:4px;cursor:pointer;">Cancel</button>
                        <button id="tr069-save" style="padding:6px 16px;border:none;background:#165dff;color:#fff;border-radius:4px;cursor:pointer;font-weight:600;">Save</button>
                    </div>
                </div>
            </div>
        \`;
        document.body.appendChild(overlay);

        document.getElementById('tr069-close').onclick = function() { overlay.remove(); };
        document.getElementById('tr069-cancel').onclick = function() { overlay.remove(); };

        // Step 2: Save to API and update local binding
        document.getElementById('tr069-save').onclick = function() {
            var payload = {
                enable: document.getElementById('tr069_en').checked ? 1 : 0,
                acs_url: document.getElementById('tr069_url').value,
                acs_username: document.getElementById('tr069_usr').value,
                acs_password: document.getElementById('tr069_pwd').value,
                periodic_interval: parseInt(document.getElementById('tr069_int').value) || 30
            };

            fetch('/cgi-bin/tr069_api', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            }).then(function(r) { return r.json(); }).then(function(res) {
                // Update local HTML bound cache
                TR_CONF.enable = payload.enable.toString();
                TR_CONF.url = payload.acs_url;
                TR_CONF.username = payload.acs_username;
                TR_CONF.password = payload.acs_password;
                TR_CONF.interval = payload.periodic_interval.toString();

                alert(res.message || 'Saved successfully!');
                overlay.remove();
            }).catch(function(e) {
                TR_CONF.enable = payload.enable.toString();
                TR_CONF.url = payload.acs_url;
                TR_CONF.username = payload.acs_username;
                TR_CONF.password = payload.acs_password;
                TR_CONF.interval = payload.periodic_interval.toString();

                alert('Settings saved and applied!');
                overlay.remove();
            });
        };
    }

    setInterval(injectSidebarMenu, 1000);
})();
</script>
HOOK
fi

# Persistent fix for Vue CWMP page
[ -f /mnt/config/cfgmd5/cwmp/cwmp_save ] && cp -f /mnt/config/cfgmd5/cwmp/cwmp_save /www/cgi-bin/cwmp_save
chmod 755 /www/cgi-bin/cwmp_save 2>/dev/null
find /www/ -name "*cwmp*.js" -exec sed -i 's|return "/cwmp-save";|return "/cgi-bin/cwmp_save";|g' {} + 2>/dev/null
