#!/bin/sh
# Copyright (C) 2015 PIVA Software <www.pivasoftware.com>
# 	Author: MOHAMED Kallel <mohamed.kallel@pivasoftware.com>

#############################
#   Entry point functuons   #
#############################

prefix_list="$prefix_list $DMROOT.IPPingDiagnostics."
entry_execute_method_list="$entry_execute_method_list entry_execute_method_root_IPPingDiagnostics"

UCI_GET_VARSTATE="/sbin/uci -q ${UCI_CONFIG_DIR:+-c $UCI_CONFIG_DIR} -P /var/state get"
UCI_SET_VARSTATE="/sbin/uci -q ${UCI_CONFIG_DIR:+-c $UCI_CONFIG_DIR} -P /var/state set"

entry_execute_method_root_IPPingDiagnostics() {
	case "$1" in ""|"$DMROOT."|"$DMROOT.IPPingDiagnostics."*)
		common_execute_method_obj "$DMROOT.IPPingDiagnostics." "0"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.DiagnosticsState" "1" "ipping_get easycwmp.@local[0].DiagnosticsState None" "ipping_set_diagnostic_state"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.Host" "1" "ipping_get easycwmp.@local[0].Host" "ipping_set easycwmp.@local[0].Host"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.NumberOfRepetitions" "1" "ipping_get easycwmp.@local[0].NumberOfRepetitions 3" "ipping_set_number easycwmp.@local[0].NumberOfRepetitions" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.Timeout" "1" "ipping_get easycwmp.@local[0].Timeout 1000" "ipping_set_number easycwmp.@local[0].Timeout" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.DataBlockSize" "1" "ipping_get easycwmp.@local[0].DataBlockSize 64" "ipping_set_number easycwmp.@local[0].DataBlockSize" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.SuccessCount" "0" "ipping_get easycwmp.@local[0].SuccessCount 0" "" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.FailureCount" "0" "ipping_get easycwmp.@local[0].FailureCount 0" "" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.AverageResponseTime" "0" "ipping_get easycwmp.@local[0].AverageResponseTime 0" "" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.MinimumResponseTime" "0" "ipping_get easycwmp.@local[0].MinimumResponseTime 0" "" "xsd:unsignedInt"
		common_execute_method_param "$DMROOT.IPPingDiagnostics.MaximumResponseTime" "0" "ipping_get easycwmp.@local[0].MaximumResponseTime 0" "" "xsd:unsignedInt"
		return 0;
		;;
	esac
	return $E_INVALID_PARAMETER_NAME;
}

#######################################
#   Data model parameters functions   #
#######################################

ipping_get() {
	local val=`$UCI_GET_VARSTATE $1`
	echo ${val:-$2}
}

ipping_set() {
	ipping_stop_diagnostic
	if [ "`$UCI_GET_VARSTATE easycwmp.@local[0].DiagnosticsState`" != "Requested" ]; then
		$UCI_SET_VARSTATE easycwmp.@local[0].DiagnosticsState=None
	fi
	$UCI_SET_VARSTATE $1=$2
	return 0
}

ipping_set_number() {
	case $2 in
		(*[^0-9]*|'') return $E_INVALID_PARAMETER_VALUE;;
	esac
	[ $2 -lt 1 ] && return $E_INVALID_PARAMETER_VALUE
	ipping_stop_diagnostic
	if [ "`$UCI_GET_VARSTATE easycwmp.@local[0].DiagnosticsState`" != "Requested" ]; then
		$UCI_SET_VARSTATE easycwmp.@local[0].DiagnosticsState=None
	fi
	$UCI_SET_VARSTATE $1=$2
	return 0
}

ipping_set_diagnostic_state() {
	local val="$1"
	case $val in 
		Requested)
			ipping_stop_diagnostic
			$UCI_SET_VARSTATE easycwmp.@local[0].DiagnosticsState=Requested
			common_execute_command_in_apply_service "/bin/sh $FUNCTION_PATH/ipping_launch run &"
			return 0
		;;
	esac
	return $E_INVALID_PARAMETER_VALUE;
}

ipping_stop_diagnostic() {
	local pids=`ps aux | grep ipping_launch | grep -v grep | awk '{print $2}'`
	if [ -n "$pids" ]; then
		kill -9 $pids
		$UCI_SET_VARSTATE easycwmp.@local[0].DiagnosticsState=None
	fi
}


#!/bin/sh
# Copyright (C) 2015 PIVA Software <www.pivasoftware.com>
# 	Author: MOHAMED Kallel <mohamed.kallel@pivasoftware.com>

#############################
#   Entry point functuons   #
#############################

prefix_list="$prefix_list $DMROOT.LANDevice."
entry_execute_method_list="$entry_execute_method_list entry_execute_method_root_LANDevice"

entry_execute_method_root_LANDevice() {
	case "$1" in ""|"$DMROOT."|"$DMROOT.LANDevice."*)
		common_execute_method_obj "$DMROOT.LANDevice." "0"
		common_execute_method_obj "$DMROOT.LANDevice.1." "0"
		common_execute_method_obj "$DMROOT.LANDevice.1.WLANConfiguration." "1" "lan_device_add_wlan_iface" "" "lan_device_browse_instances_wlan_iface $1"
		return 0
		;;
	esac
	return $E_INVALID_PARAMETER_NAME;
}

sub_entry_landevice_wlanconfig() {
	local j="$2"
	local iface="$3"
	case_param "$1" belongto "$DMROOT.LANDevice.1.WLANConfiguration.$j." && {
		common_execute_method_obj "$DMROOT.LANDevice.1.WLANConfiguration.$j." "1" "" "lan_device_delete_wlan_iface $iface"
		common_execute_method_param "$DMROOT.LANDevice.1.WLANConfiguration.$j.Enable" "1" "lan_device_get_wlan_enable" "lan_device_set_wlan_enable" "xsd:boolean"
		common_execute_method_param "$DMROOT.LANDevice.1.WLANConfiguration.$j.SSID" "1" "$UCI_GET wireless.$iface.ssid" "lan_device_set_wlan_cfg wireless.$iface.ssid"
		return 0
	}
	return $E_INVALID_PARAMETER_NAME;
}

#######################################
#     Data model browse instances     #
#######################################

lan_device_browse_instances_wlan_iface() {
	local iface ifaces=`$UCI_SHOW wireless | grep "wireless\.@wifi-iface\[.*\]=wifi-iface" | awk -F'[.=]' '{print $2}'` 
	for iface in $ifaces; do
		local j=`lan_device_update_instance $iface`
		sub_entry_landevice_wlanconfig "$1" "$j" "$iface"
	done
	return 0
}

#######################################
#   Data model parameters functions   #
#######################################

lan_device_get_wlan_enable() {
	local val=`$UCI_GET wireless.wl0.disabled 2> /dev/null`
	[ "$val" = "1" ] && echo "0" || echo "1"
}

lan_device_set_wlan_enable() {
	local val="$1"
	common_set_bool "wireless.wl0.disabled" "$val" "0" "1"
	local e="$?"
	[ "$e" != "0" ] && return $e
	return 0
}

lan_device_set_wlan_cfg() {
	local cfg="$1"
	local val="$2"
	$UCI_SET $cfg="$val"
	return 0
}

lan_device_get_wlan_max_instance() {
	local max=`$UCI_SHOW wireless | grep "wireless\.@wifi-iface\[[0-9]\+\].instance=" | cut -d'=' -f2 | sed 's/[^0-9]*//g' | sort -nru | head -1`
	echo ${max:-0}
}

lan_device_update_instance() {
	local iface="$1"
	local instance=`$UCI_GET wireless.$iface.instance`
	if [ -z "$instance" ]; then
		instance=`lan_device_get_wlan_max_instance`
		$UCI_SET wireless.$iface.instance=$((++instance))
		$UCI_COMMIT
	fi
	echo $instance
}

lan_device_add_wlan_iface() {
	local instance=`lan_device_get_wlan_max_instance`
	local wifi_iface=`$UCI_ADD wireless wifi-iface`
	$UCI_SET wireless.$wifi_iface.device=wl0
	$UCI_SET wireless.$wifi_iface.encryption=none
	$UCI_SET wireless.$wifi_iface.mode=ap
	$UCI_SET wireless.$wifi_iface.ssid=DefaultSSID
	$UCI_SET wireless.$wifi_iface.instance=$((++instance))
	$UCI_COMMIT
	echo $instance
}

lan_device_delete_wlan_iface() {
	local iface="$1"
	$UCI_DELETE wireless.$iface
	$UCI_COMMIT
	return 0
}
#!/bin/sh
# Copyright (C) 2015 PIVA Software <www.pivasoftware.com>
# 	Author: MOHAMED Kallel <mohamed.kallel@pivasoftware.com>

#############################
#   Entry point functuons   #
#############################

prefix_list="$prefix_list $DMROOT.WANDevice."
entry_execute_method_list="$entry_execute_method_list entry_execute_method_root_WANDevice"
entry_execute_method_list_forcedinform="$entry_execute_method_list_forcedinform entry_execute_method_root_WANDevice"


entry_execute_method_root_WANDevice() {
	case "$1" in ""|"$DMROOT."|"$DMROOT.WANDevice."*)
		common_execute_method_obj "$DMROOT.WANDevice." "0"
		common_execute_method_obj "$DMROOT.WANDevice.1." "0"
		common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice." "0" "" "" "wan_device_browse_instances_wancxdev $1"
		return 0
		;;
	esac
	return $E_INVALID_PARAMETER_NAME;
}

sub_entry_wandevice_wanconnectiondevice() {
	local j="$2"
	local iface="$3"
	local protocol="$4"
	local default="$5"
	case_param "$1" belongto "$DMROOT.WANDevice.1.WANConnectionDevice.$j." && {
		common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice.$j." "0"
		case $protocol in
			IP)
			common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANIPConnection." "0"
			common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANIPConnection.1." "0"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANIPConnection.1.ConnectionStatus" "0" "wan_device_get_ipcx_status"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANIPConnection.1.ExternalIPAddress" "0" "wan_device_get_ipcx_ipaddr $iface" "" "" "$default"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANIPConnection.1.MACAddress" "0" "wan_device_get_ipcx_macaddr $iface"
			;;
			PPP)
			common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANPPPConnection." "0"
			common_execute_method_obj "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANPPPConnection.1." "0"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANPPPConnection.1.Enable" "1" "wan_device_get_ipcx_macaddr $iface" "wan_device_set_wan_ppp_enable $iface" "xsd:boolean"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANPPPConnection.1.Username" "1" "$UCI_GET network.$iface.username" "wan_device_set_wan_ppp_cfg network.$iface.username"
			common_execute_method_param "$DMROOT.WANDevice.1.WANConnectionDevice.$j.WANPPPConnection.1.Password" "1" "" "wan_device_set_wan_ppp_cfg network.$iface.password"
			;;
		esac
		return 0
	}
	return $E_INVALID_PARAMETER_NAME;
}

#######################################
#     Data model browse instances     #
#######################################

wan_device_browse_instances_wancxdev() {
	local map maps=`wan_device_get_interface_maps` 
	for map in $maps; do
		local iface=${map%%:*}
		map=${map#*:}
		local j=${map%%:*}
		map=${map#*:}
		local protocol=${map%%:*}
		local default=${map#*:}
		sub_entry_wandevice_wanconnectiondevice "$1" "$j" "$iface" "$protocol" "$default"
	done
	return 0;
}

#######################################
#   Data model parameters functions   #
#######################################

wan_device_get_interface_maps() {
	#should return a list like this: "<interface1>:<instance1>:<protocol>:<default interface? 1 : 0> <interface2>:<instance>:<protocol>:<default interface? 1 : 0>"
	echo "mng:1:IP:1 wan:2:PPP:0"
}

wan_device_get_ipcx_status() {
	echo "Connected"
}

wan_device_get_ipcx_ipaddr() {
	local val iface="$1"
	network_get_ipaddr val "$iface"
	echo "$val"
}

wan_device_get_ipcx_macaddr() {
	local val iface="$1"
	if [ -z "$default_wan_device_mng_interface_mac" ]; then
		val=`$UCI_GET network.$iface.macaddr`
	else
		val=$default_wan_device_mng_interface_mac
	fi
	echo $val
}

wan_device_get_wan_ppp_enable() {
	local iface="$1"
	local val=`$UCI_GET network.$iface.auto`
	echo ${val:-1}
}

wan_device_set_wan_ppp_enable() {
	local iface="$1"
	local val="$2"
	common_set_bool "network.$iface.auto" "$val" "1" "0"
	local e="$?"
	[ "$e" != "0" ] && return $e
	return 0
}

wan_device_set_wan_ppp_cfg() {
	local cfg="$1"
	local val="$2"
	$UCI_SET $cfg="$val"
	return 0
}
