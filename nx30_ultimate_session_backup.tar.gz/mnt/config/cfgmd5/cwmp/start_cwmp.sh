#!/bin/sh

# ১. যেকোনো অ্যাক্টিভ ডিফল্ট ইন্টারফেস ডায়নামিকালি ধরা
CURR_IF=$(route -n 2>/dev/null | awk '$1=="0.0.0.0" {print $8}' | head -n 1)
[ -z "$CURR_IF" ] && CURR_IF=$(uci -q get network.wan.ifname)

if [ -n "$CURR_IF" ]; then
    CONF_IF=$(uci -q get easycwmp.local.interface)
    if [ "$CONF_IF" != "$CURR_IF" ]; then
        uci set easycwmp.local.interface="$CURR_IF"
        uci commit easycwmp
    fi
fi

# ২. ডিরেক্টরি সিঙ্ক
mkdir -p /usr/share/easycwmp /usr/share
cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/easycwmp/ 2>/dev/null
cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/ 2>/dev/null
[ -f /mnt/config/cfgmd5/cwmp/sbin/easycwmp ] && cp -f /mnt/config/cfgmd5/cwmp/sbin/easycwmp /usr/sbin/easycwmp

# ৩. প্রসেস রিস্টার্ট
killall -9 easycwmpd update_hosts.sh 2>/dev/null

(while true; do
    /bin/sh /mnt/config/cfgmd5/cwmp/update_hosts.sh >/dev/null 2>&1
    sleep 20
done) &

export LD_LIBRARY_PATH="/mnt/config/cfgmd5/cwmp/lib:/usr/lib:/lib:$LD_LIBRARY_PATH"
/mnt/config/cfgmd5/cwmp/bin/easycwmpd -b

echo "easycwmpd started with interface: $(uci -q get easycwmp.local.interface)"
