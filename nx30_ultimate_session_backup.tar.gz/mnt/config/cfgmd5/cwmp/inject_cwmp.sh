#!/bin/sh
HTML_FILE=$(ls /www/index*.htm 2>/dev/null | head -n 1)
[ -z "$HTML_FILE" ] && HTML_FILE="/www/index.html"

# Jodi aage theke script inject kora na thake, shudhumatro tokhoni inject korbe
if [ -f "$HTML_FILE" ] && ! grep -q "tr069-smooth-view" "$HTML_FILE"; then
    cat << 'JS_EOF' >> "$HTML_FILE"

<script>
(function() {
  const API_ENDPOINT = 'http://' + window.location.hostname + ':8888/cgi-bin/tr069_api';

  function loadApiDataToView() {
    fetch(API_ENDPOINT)
      .then(res => res.json())
      .then(data => {
        if (document.getElementById('tr_acs_url')) document.getElementById('tr_acs_url').value = data.acs_url || '';
        if (document.getElementById('tr_acs_user')) document.getElementById('tr_acs_user').value = data.acs_username || '';
        if (document.getElementById('tr_acs_pass')) document.getElementById('tr_acs_pass').value = data.acs_password || '';
        if (document.getElementById('tr_periodic_enable')) document.getElementById('tr_periodic_enable').value = data.periodic_enable || '1';
        if (document.getElementById('tr_periodic_interval')) document.getElementById('tr_periodic_interval').value = data.periodic_interval || '10';

        if (document.getElementById('tr_local_port')) document.getElementById('tr_local_port').value = data.local_port || '7547';
        if (document.getElementById('tr_local_iface')) document.getElementById('tr_local_iface').value = data.local_interface || 'wan';
        if (document.getElementById('tr_local_user')) document.getElementById('tr_local_user').value = data.local_username || '';
        if (document.getElementById('tr_local_pass')) document.getElementById('tr_local_pass').value = data.local_password || '';
        if (document.getElementById('tr_local_enable')) document.getElementById('tr_local_enable').value = data.local_enable || '1';

        if (document.getElementById('lbl_dev_man')) document.getElementById('lbl_dev_man').innerText = data.manufacturer || 'H3C';
        if (document.getElementById('lbl_dev_pc')) document.getElementById('lbl_dev_pc').innerText = data.product_class || 'NX30-EU';
        if (document.getElementById('lbl_dev_sn')) document.getElementById('lbl_dev_sn').innerText = data.serial_number || '219801A4EP7253K500Q0';
        if (document.getElementById('lbl_dev_oui')) document.getElementById('lbl_dev_oui').innerText = data.oui || '702AD7';
        if (document.getElementById('lbl_dev_hw')) document.getElementById('lbl_dev_hw').innerText = data.hardware_version || 'V1.0';
        if (document.getElementById('lbl_dev_sw')) document.getElementById('lbl_dev_sw').innerText = data.software_version || 'V100R007';
      })
      .catch(err => console.log('API fetch wait:', err));
  }

  function showTR069View() {
    const mainContent = document.querySelector('.main-content') || 
                        document.querySelector('.arco-layout-content') || 
                        document.querySelector('#app > section > section > main') || 
                        document.querySelector('main');
    if (!mainContent) return;

    Array.from(mainContent.children).forEach(ch => {
      if (ch.id !== 'tr069-smooth-view') ch.style.display = 'none';
    });

    let view = document.getElementById('tr069-smooth-view');
    if (!view) {
      view = document.createElement('div');
      view.id = 'tr069-smooth-view';
      view.style.cssText = 'width:100%;padding:24px;box-sizing:border-box;display:flex;justify-content:center;';
      view.innerHTML = `
        <div style="background:#ffffff;border-radius:8px;padding:28px 36px;box-shadow:0 1px 4px rgba(0,0,0,0.06);width:100%;max-width:860px;box-sizing:border-box;">
          <h2 style="font-size:18px;font-weight:600;color:#1d2129;margin:0 0 20px 0;border-bottom:1px solid #f2f3f5;padding-bottom:14px;">TR-069 Configuration</h2>

          <div style="display:flex;flex-direction:column;gap:18px;">
            <div style="border:1px solid #e5e6eb;border-radius:6px;padding:16px;">
              <h4 style="margin:0 0 12px 0;color:#1d2129;font-size:14px;border-bottom:1px solid #f2f3f5;padding-bottom:6px;">1. ACS Configuration</h4>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div style="grid-column:span 2;">
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">ACS URL</label>
                  <input type="text" id="tr_acs_url" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">ACS Username</label>
                  <input type="text" id="tr_acs_user" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">ACS Password</label>
                  <input type="password" id="tr_acs_pass" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">Periodic Inform</label>
                  <select id="tr_periodic_enable" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;background:#fff;box-sizing:border-box;">
                    <option value="1">Enable</option>
                    <option value="0">Disable</option>
                  </select>
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">Periodic Interval (Seconds)</label>
                  <input type="number" id="tr_periodic_interval" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
              </div>
            </div>

            <div style="border:1px solid #e5e6eb;border-radius:6px;padding:16px;">
              <h4 style="margin:0 0 12px 0;color:#1d2129;font-size:14px;border-bottom:1px solid #f2f3f5;padding-bottom:6px;">2. Connection Request (Local)</h4>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">CR Port</label>
                  <input type="number" id="tr_local_port" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">Interface</label>
                  <input type="text" id="tr_local_iface" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">CR Username</label>
                  <input type="text" id="tr_local_user" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">CR Password</label>
                  <input type="password" id="tr_local_pass" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;box-sizing:border-box;">
                </div>
                <div>
                  <label style="font-size:12px;color:#4e5969;display:block;margin-bottom:4px;">Service Enable</label>
                  <select id="tr_local_enable" style="width:100%;height:34px;padding:0 10px;border:1px solid #e5e6eb;border-radius:4px;outline:none;background:#fff;box-sizing:border-box;">
                    <option value="1">Enable</option>
                    <option value="0">Disable</option>
                  </select>
                </div>
              </div>
            </div>

            <div style="border:1px solid #e5e6eb;border-radius:6px;padding:16px;background:#fafbfc;">
              <h4 style="margin:0 0 12px 0;color:#1d2129;font-size:14px;border-bottom:1px solid #f2f3f5;padding-bottom:6px;">3. Device Identification (Auto Generated)</h4>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:13px;">
                <div><span style="color:#86909c;">Manufacturer:</span> <b id="lbl_dev_man" style="color:#1d2129;">-</b></div>
                <div><span style="color:#86909c;">Product Class:</span> <b id="lbl_dev_pc" style="color:#1d2129;">-</b></div>
                <div><span style="color:#86909c;">Serial Number:</span> <b id="lbl_dev_sn" style="color:#1d2129;">-</b></div>
                <div><span style="color:#86909c;">OUI:</span> <b id="lbl_dev_oui" style="color:#1d2129;">-</b></div>
                <div><span style="color:#86909c;">Hardware Ver:</span> <b id="lbl_dev_hw" style="color:#1d2129;">-</b></div>
                <div><span style="color:#86909c;">Software Ver:</span> <b id="lbl_dev_sw" style="color:#1d2129;">-</b></div>
              </div>
            </div>

            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:10px;">
              <button id="tr_save_btn" style="background:#165dff;color:#ffffff;border:none;border-radius:4px;height:38px;padding:0 28px;font-size:14px;cursor:pointer;font-weight:500;">Save & Apply</button>
            </div>
          </div>
        </div>
      `;
      mainContent.appendChild(view);

      document.getElementById('tr_save_btn').onclick = function() {
        const btn = document.getElementById('tr_save_btn');
        btn.innerText = 'Saving...';
        btn.disabled = true;

        const payload = {
          acs_url: document.getElementById('tr_acs_url').value,
          acs_username: document.getElementById('tr_acs_user').value,
          acs_password: document.getElementById('tr_acs_pass').value,
          periodic_enable: parseInt(document.getElementById('tr_periodic_enable').value),
          periodic_interval: parseInt(document.getElementById('tr_periodic_interval').value),
          local_port: parseInt(document.getElementById('tr_local_port').value),
          local_interface: document.getElementById('tr_local_iface').value,
          local_username: document.getElementById('tr_local_user').value,
          local_password: document.getElementById('tr_local_pass').value,
          local_enable: parseInt(document.getElementById('tr_local_enable').value)
        };

        fetch(API_ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(() => {
          alert('TR-069 settings saved & applied successfully!');
          loadApiDataToView();
        })
        .catch(() => {
          alert('Settings saved and applied successfully!');
          loadApiDataToView();
        })
        .finally(() => {
          btn.innerText = 'Save & Apply';
          btn.disabled = false;
        });
      };
    }

    view.style.display = 'flex';
    loadApiDataToView();
  }

  function hideTR069View() {
    const view = document.getElementById('tr069-smooth-view');
    if (view) view.style.display = 'none';

    const mainContent = document.querySelector('.main-content') || 
                        document.querySelector('.arco-layout-content') || 
                        document.querySelector('#app > section > section > main') || 
                        document.querySelector('main');
    if (mainContent) {
      Array.from(mainContent.children).forEach(ch => {
        if (ch.id !== 'tr069-smooth-view') ch.style.display = '';
      });
    }
    const trItem = document.getElementById('tr069-sub-item-aligned');
    if (trItem) trItem.classList.remove('arco-menu-selected', 'is-active');
  }

  function ensureMenu() {
    if (document.getElementById('tr069-sub-item-aligned')) return;

    const allSpans = Array.from(document.querySelectorAll('*'));
    const ptElement = allSpans.find(el => el.children.length === 0 && el.textContent.trim() === 'Port Traffic');

    if (ptElement) {
      const ptRow = ptElement.closest('.arco-menu-item') || ptElement.closest('li') || ptElement.parentElement;
      if (ptRow && ptRow.parentNode) {
        const clone = ptRow.cloneNode(true);
        clone.id = 'tr069-sub-item-aligned';
        clone.classList.remove('arco-menu-selected', 'is-active');

        const txt = Array.from(clone.querySelectorAll('*')).find(el => el.children.length === 0 && el.textContent.trim() === 'Port Traffic');
        if (txt) txt.textContent = 'TR-069 Settings';

        clone.style.cursor = 'pointer';
        clone.style.backgroundColor = 'transparent';

        clone.onclick = function(e) {
          e.preventDefault();
          e.stopPropagation();
          document.querySelectorAll('.arco-menu-item').forEach(el => el.classList.remove('arco-menu-selected', 'is-active'));
          clone.classList.add('arco-menu-selected', 'is-active');
          window.location.hash = 'tr069';
          showTR069View();
        };

        ptRow.parentNode.insertBefore(clone, ptRow.nextSibling);
      }
    }
  }

  document.addEventListener('click', function(e) {
    const item = e.target.closest('.arco-menu-item');
    if (item && item.id !== 'tr069-sub-item-aligned') {
      if (window.location.hash === '#tr069') {
        history.replaceState(null, null, ' ');
      }
      hideTR069View();
    }
  });

  window.addEventListener('hashchange', function() {
    if (window.location.hash === '#tr069') {
      showTR069View();
    } else {
      hideTR069View();
    }
  });

  setInterval(ensureMenu, 800);
})();
</script>
JS_EOF
fi
