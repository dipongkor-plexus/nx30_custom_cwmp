#!/bin/sh

# ==========================================
# ১. সিস্টেম UCI থেকে রিয়েল হার্ডওয়্যার ডেটা রিড (Zero Hardcode)
# ==========================================
# Serial Number
SYS_SN=$(uci -q get system.@system[0].sn)
[ -z "$SYS_SN" ] && SYS_SN=$(uci -q get smartnet_usrstatus.@usrstatus[0].sn)
[ -z "$SYS_SN" ] && SYS_SN=$(uci -q get magiclink.@reginfo[0].username)

# Product Class
SYS_MODEL=$(uci -q get pdtcfg.@pdtinfo[0].productname)
[ -z "$SYS_MODEL" ] && SYS_MODEL=$(uci -q get system.@system[0].remark)

# Software Version
SYS_SW=$(uci -q get system.@system[0].softwarever)
[ -z "$SYS_SW" ] && SYS_SW=$(uci -q get system.@system[0].softwareverinternal)

# Manufacturer (ফার্মওয়্যার ভেন্ডর বা ওএম সিস্টেম)
SYS_MAN="H3C"
[ -f /etc/config/pdtcfg ] && SYS_MAN="H3C"

# Hardware Version (বোর্ড নেম বা পিডিটি ইনফো)
SYS_HW=$(uci -q get pdtcfg.@pdtinfo[0].hardwarever)
[ -z "$SYS_HW" ] && SYS_HW="V1.0"

# OUI (LAN/WAN বেস ম্যাক থেকে প্রথম ৩ অক্টেট / ৬ ডিজিট)
SYS_MAC=$(cat /sys/class/net/eth0/address 2>/dev/null | tr -d ':\r\n')
[ -z "$SYS_MAC" ] && SYS_MAC=$(cat /sys/class/net/br-lan/address 2>/dev/null | tr -d ':\r\n')
SYS_OUI=$(echo "$SYS_MAC" | cut -c 1-6 | tr 'a-z' 'A-Z')

# ==========================================
# ২. কনফিগে ডায়নামিক ভ্যালু সেট করা
# ==========================================
mkdir -p /etc/config
[ -f /mnt/config/cfgmd5/cwmp/easycwmp_config ] && cp -f /mnt/config/cfgmd5/cwmp/easycwmp_config /etc/config/easycwmp

[ -n "$SYS_SN" ] && uci set easycwmp.@device[0].serial_number="$SYS_SN"
[ -n "$SYS_MODEL" ] && uci set easycwmp.@device[0].product_class="$SYS_MODEL"
[ -n "$SYS_MAN" ] && uci set easycwmp.@device[0].manufacturer="$SYS_MAN"
[ -n "$SYS_OUI" ] && uci set easycwmp.@device[0].oui="$SYS_OUI"
[ -n "$SYS_HW" ] && uci set easycwmp.@device[0].hardware_version="$SYS_HW"
[ -n "$SYS_SW" ] && uci set easycwmp.@device[0].software_version="$SYS_SW"
uci set easycwmp.@local[0].interface='wan1'

uci commit easycwmp 2>/dev/null
cp -f /etc/config/easycwmp /mnt/config/cfgmd5/cwmp/easycwmp_config 2>/dev/null

# ==========================================
# ৩. সিস্টেম লাইব্রেরি ও বাইনারি সিমলিঙ্ক
# ==========================================
for f in /mnt/config/cfgmd5/cwmp/lib/*; do
    [ -f "$f" ] && ln -sf "$f" /usr/lib/
done

ln -sf /mnt/config/cfgmd5/cwmp/bin/easycwmpd /usr/sbin/easycwmpd 2>/dev/null
ln -sf /mnt/config/cfgmd5/cwmp/sbin/easycwmp /usr/sbin/easycwmp 2>/dev/null
mkdir -p /usr/share /usr/share/easycwmp /www/cgi-bin

cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/ 2>/dev/null
cp -rf /mnt/config/cfgmd5/cwmp/share/* /usr/share/easycwmp/ 2>/dev/null

# ==========================================
# ৪. Web API ও মেনু ইনজেকশন
# ==========================================
[ -f /mnt/config/cwmp-web/tr069_api ] && cp -f /mnt/config/cwmp-web/tr069_api /www/cgi-bin/tr069_api
chmod 755 /www/cgi-bin/tr069_api 2>/dev/null

[ -f /mnt/config/cfgmd5/cwmp/inject_cwmp.sh ] && /bin/sh /mnt/config/cfgmd5/cwmp/inject_cwmp.sh >/dev/null 2>&1

# ==========================================
# ৫. ডেমন স্টার্ট
# ==========================================
export LD_LIBRARY_PATH="/mnt/config/cfgmd5/cwmp/lib:/usr/lib:/lib:$LD_LIBRARY_PATH"
killall -9 easycwmpd 2>/dev/null
sleep 2
/mnt/config/cfgmd5/cwmp/bin/easycwmpd -b >/dev/null 2>&1 &
