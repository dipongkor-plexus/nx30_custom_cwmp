#!/bin/sh
EXPIRY=$(($(date +%s) + 86400))
TMP="/tmp/dhcp.leases.tmp"

> "$TMP"
while read -r ip hw flags mac mask dev; do
    [ "$dev" = "br-lan" ] || continue
    [ "$mac" = "00:00:00:00:00:00" ] && continue
    [ -z "$ip" ] || [ -z "$mac" ] && continue

    clean_mac=$(echo "$mac" | tr 'A-Z' 'a-z')
    echo "$EXPIRY $clean_mac $ip Host-$clean_mac *" >> "$TMP"
done < /proc/net/arp

if [ -s "$TMP" ]; then
    cp -f "$TMP" /tmp/dhcp.leases
fi
rm -f "$TMP"
